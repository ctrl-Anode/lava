<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class TermsController extends Controller {
    public function __construct()
    {
        parent:: __construct();
        $this->call->model('terms_model');
    }
	public function read()
    {
        $userdata['terms']=$this->terms_model->read();
        $this->call->view('terms/view_terms', $userdata);
    }
    public function create()
    {
        if($this->form_validation->submitted()){
            $this->form_validation
                ->name('TermText')
                     ->required('TermText is required!')
                ->name('status')
                     ->required('Status is required!');
        if($this->form_validation->run()){
            $TermText = $this->io->post('TermText');
            $status = $this->io->post('status');

            if($this->terms_model->create($TermText, $status)){
               set_flash_alert('success', 'Terms was added successfully!');
               redirect('auth/terms/display');
            }
        }
        else{
               set_flash_alert('danger', $this->form_validation->errors());
               redirect('auth/terms/create');
        }
        }
        $this->call->view('terms/add_terms');
    }
    public function update($id)
{
    if ($this->form_validation->submitted()) {
        // Define validation rules
        $this->form_validation
            ->name('TermText')->required('TermText is required!')
            ->name('status')->required('Status is required!');

        // Run validation
        if ($this->form_validation->run()) {
            // Collect form data
            $data = [
                'TermText' => $this->io->post('TermText'),
                'status' => $this->io->post('status'),
                
            ];

            // Update user data in the database
            if ($this->terms_model->update($id, $data)) {
                set_flash_alert('success', 'terms data was updated successfully!');
                redirect('auth/terms/display');
                return;
            } else {
                set_flash_alert('danger', 'Failed to update user data.');
                redirect('auth/terms/display');
                return;
            }
        } else {
            // Handle validation errors
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('auth/terms/display');
            return;
        }
    }

    // Load user data for the view
    $userdata['term'] = $this->terms_model->get_one($id);
    $this->call->view('terms/edit_terms', $userdata);
}

    public function delete($id){
        if($this->terms_model->delete($id)){
            set_flash_alert('success', 'terms data was deleted successfully!');
            redirect('auth/terms/display');
        }else{
            set_flash_alert('danger', 'Something Went Wrong!');
            redirect('auth/terms/display');
        }
    }
    
}
?>
