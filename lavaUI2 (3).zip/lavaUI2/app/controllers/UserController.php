<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class UserController extends Controller {
    public function __construct()
    {
        parent:: __construct();
        $this->call->model('user_model');
    }
	public function user_read()
    {
        $userdata['users']=$this->user_model->read();
        $this->call->view('user/user_manage', $userdata);
    }
    public function update($id)
{
    if ($this->form_validation->submitted()) {
        // Define validation rules
        $this->form_validation
            ->name('TermText')->required('TermText is required!')
            ->name('status')->required('Status is required!');

        // Run validation
        if ($this->form_validation->run()) {
            // Collect form data
            $data = [
                'TermText' => $this->io->post('TermText'),
                'status' => $this->io->post('status'),
                
            ];

            // Update user data in the database
            if ($this->terms_model->update($id, $data)) {
                set_flash_alert('success', 'terms data was updated successfully!');
                redirect('auth/terms/display');
                return;
            } else {
                set_flash_alert('danger', 'Failed to update user data.');
                redirect('auth/terms/display');
                return;
            }
        } else {
            // Handle validation errors
            set_flash_alert('danger', $this->form_validation->errors());
            redirect('auth/terms/display');
            return;
        }
    }

    // Load user data for the view
    $userdata['term'] = $this->terms_model->get_one($id);
    $this->call->view('terms/edit_terms', $userdata);
}

    public function user_delete($id){
        if($this->user_model->delete($id)){
            set_flash_alert('success', 'terms data was deleted successfully!');
            redirect('auth/user/manage');
        }else{
            set_flash_alert('danger', 'Something Went Wrong!');
            redirect('auth/user/manage');
        }
    }
    public function profile() {
        // Load the Lauth library to check if the user is logged in
        $this->call->library('lauth');
        
        // Check if the user is logged in
        if (!$this->lauth->is_logged_in()) {
            // Redirect to login page if not logged in
            redirect('auth/login');
        }

        // Get the user ID from the session
        $user_id = $this->lauth->get_user_id();

        // Load the User model
        $this->call->model('user_model');

        // Retrieve user data
        $data['user'] = $this->user_model->get_user($user_id);

        // Load the profile view and pass the user data
        $this->call->view('user/profile', $data);

    }
    public function update_profile() {
        // Load the Lauth library to check if the user is logged in
        $this->call->library('lauth');
        
        // Check if the user is logged in
        if (!$this->lauth->is_logged_in()) {
            redirect('auth/login');
        }

        // Get the user ID from the session
        $user_id = $this->lauth->get_user_id();

        // Load the User model
        $this->call->model('user_model');

        // Prepare data for update
        $data = [
            'fname' => $this->io->post('fname'),
            'mname' => $this->io->post('mname'),
            'lname' => $this->io->post('lname'),
            'uname' => $this->io->post('uname'),
            'email' => $this->io->post('email'),
            'contact' => $this->io->post('contact'),
            'address' => $this->io->post('address'),
        ];

        // Update user data in the database
        $this->user_model->update_user($user_id, $data);

        // Redirect to the profile page with a success message
        redirect('user/profile');
    }
    
}
?>
