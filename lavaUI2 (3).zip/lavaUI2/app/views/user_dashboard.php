<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard - Gym Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-64 min-h-screen flex flex-col">
            <div class="p-4">
                <h2 class="text-2xl font-bold">Perfect Fitness Gym</h2>
            </div>
            <nav class="flex-1">
                <a href="<?=site_url('user/profile')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-user mr-2"></i> Profile
                    
                </a>
                <a href="<?=site_url('dashboard')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
                </a>
                <a href="memberships/display" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-clipboard-list mr-2"></i> My Membership Plan
                </a>
                <a href="<?=site_url('user/memberships/display')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-plus-circle mr-2"></i> Avail Membership Plan
                </a>
                <a href="<?=site_url('user/class/display')?>" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-dumbbell mr-2"></i> Book Class
                </a>
                <a href="#" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-calendar-alt mr-2"></i> Scheduled Classes
                </a>
                <a href="#" class="block py-2 px-4 hover:bg-gray-700 transition duration-200">
                    <i class="fas fa-money-bill-wave mr-2"></i> Payments
                </a>
            </nav>
            <div class="p-4">
                <a href="<?=site_url('user/user_logout');?>" class="block py-2 px-4 bg-red-500 text-white rounded hover:bg-red-600 transition duration-200">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </a>
            </div>
        </div>

        <!-- Main content -->
        <div class="flex-1 p-10">
            <h1 class="text-3xl font-bold mb-8">Dashboard</h1>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Membership Plan Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold mb-4">Current Membership Plan</h2>
                    <div id="membershipPlanChart" class="w-full h-64"></div>
                </div>

                <!-- Booked Classes Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold mb-4">Booked Classes</h2>
                    <div id="bookedClassesChart" class="w-full h-64"></div>
                </div>

                <!-- Payments Card -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold mb-4">Recent Payments</h2>
                    <div id="paymentsChart" class="w-full h-64"></div>
                </div>
            </div>

            <!-- Scheduled Classes Table -->
            <div class="mt-8 bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Upcoming Scheduled Classes</h2>
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="py-2 px-4 text-left">Class Name</th>
                            <th class="py-2 px-4 text-left">Date</th>
                            <th class="py-2 px-4 text-left">Time</th>
                            <th class="py-2 px-4 text-left">Instructor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="py-2 px-4">Yoga</td>
                            <td class="py-2 px-4">2023-05-15</td>
                            <td class="py-2 px-4">09:00 AM</td>
                            <td class="py-2 px-4">John Doe</td>
                        </tr>
                        <tr class="bg-gray-50">
                            <td class="py-2 px-4">Spinning</td>
                            <td class="py-2 px-4">2023-05-16</td>
                            <td class="py-2 px-4">06:00 PM</td>
                            <td class="py-2 px-4">Jane Smith</td>
                        </tr>
                        <!-- Add more rows as needed -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Membership Plan Chart
        new Chart(document.getElementById('membershipPlanChart'), {
            type: 'doughnut',
            data: {
                labels: ['Days Used', 'Days Remaining'],
                datasets: [{
                    data: [20, 10],
                    backgroundColor: ['#4CAF50', '#FFA000']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                title: {
                    display: true,
                    text: '30-Day Membership'
                }
            }
        });

        // Booked Classes Chart
        new Chart(document.getElementById('bookedClassesChart'), {
            type: 'bar',
            data: {
                labels: ['Yoga', 'Spinning', 'Zumba', 'Pilates', 'Boxing'],
                datasets: [{
                    label: 'Classes Booked',
                    data: [3, 2, 1, 4, 2],
                    backgroundColor: '#3F51B5'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        stepSize: 1
                    }
                }
            }
        });

        // Payments Chart
        new Chart(document.getElementById('paymentsChart'), {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                datasets: [{
                    label: 'Monthly Payments ($)',
                    data: [50, 60, 55, 70, 65],
                    borderColor: '#00BCD4',
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>

