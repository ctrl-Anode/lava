<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Your Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        /* Same styles as before */
        :root {
            --primary-color: #343a40;
            --secondary-color: #495057;
            --text-color: #f8f9fa;
            --hover-color: #6c757d;
            --transition-speed: 0.3s;
        }
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            background-color: var(--primary-color);
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
            color: var(--text-color);
            transition: transform var(--transition-speed);
            z-index: 1000;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left var(--transition-speed);
        }
        .card {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <?php include APP_DIR . 'views/templates/usersidebar.php'; ?>

    <!-- Main content -->
    <div class="main-content">
        <div class="container">
            <h1 class="mb-4 fas fa-user-alt me-1"> Your Profile</h1>
            
            <!-- Display Profile Card -->
            <div id="profile-card" class="card">
                <div class="card-body">
                    <form action="<?=site_url('user/user_logout');?>">
                        <h5 class="card-title fas fa-user-alt me-1"> <?= html_escape($user['uname']); ?></h5><br><br>
                        <p class="card-text"><strong>Email:</strong> <?= html_escape($user['email']); ?></p>
                        <p class="card-text"><strong>Full Name:</strong> <?= html_escape($user['fname'] . ' ' . $user['mname'] . ' ' . $user['lname']); ?></p>
                        <p class="card-text"><strong>Gender:</strong> <?= html_escape($user['gender']); ?></p>
                        <p class="card-text"><strong>Contact:</strong> <?= html_escape($user['contact']); ?></p>
                        <p class="card-text"><strong>Address:</strong> <?= html_escape($user['address']); ?></p>
                        <button class="btn btn-sm btn-danger">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </button>
                    </form><br>
                    <button id="update-profile-btn" class="btn btn-sm btn-primary">
                        <i class="fas fa-edit me-1"></i>Update Profile
                    </button>
                </div>
            </div>

            <!-- Update Form (Hidden by Default) -->
            <form id="update-form" class="hidden" action="<?= site_url('user/update_profile'); ?>" method="POST">
                <div class="mb-3">
                    <label for="fname" class="form-label">First Name:</label>
                    <input type="text" class="form-control" id="fname" name="fname" value="<?= html_escape($user['fname']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="mname" class="form-label">Middle Name:</label>
                    <input type="text" class="form-control" id="mname" name="mname" value="<?= html_escape($user['mname']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="lname" class="form-label">Last Name:</label>
                    <input type="text" class="form-control" id="lname" name="lname" value="<?= html_escape($user['lname']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="uname" class="form-label">Username:</label>
                    <input type="text" class="form-control" id="uname" name="uname" value="<?= html_escape($user['uname']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= html_escape($user['email']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="contact" class="form-label">Contact:</label>
                    <input type="text" class="form-control" id="contact" name="contact" value="<?= html_escape($user['contact']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Address:</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?= html_escape($user['address']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <button type="button" id="cancel-update-btn" class="btn btn-secondary">Cancel</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            // Show update form when the button is clicked
            $('#update-profile-btn').click(function () {
                $('#profile-card').hide(); // Hide the profile card
                $('#update-form').removeClass('hidden'); // Show the update form
            });

            // Cancel update and show the profile card
            $('#cancel-update-btn').click(function () {
                $('#update-form').addClass('hidden'); // Hide the update form
                $('#profile-card').show(); // Show the profile card
            });

            // Client-side validation
            $('#update-form').on('submit', function (e) {
                let isValid = true;
                const username = $('#uname').val();
                const email = $('#email').val();
                const contact = $('#contact').val();

                // Username validation
                if (username.length < 5 || username.length > 20 || !/^[a-zA-Z0-9-_]+$/.test(username)) {
                    alert('Username must be 5-20 characters long and contain only letters, numbers, dashes, or underscores.');
                    isValid = false;
                }

                // Email validation
                if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
                    alert('Please enter a valid email address.');
                    isValid = false;
                }

                // Contact validation
                if (!/^\d{10,15}$/.test(contact)) {
                    alert('Contact number must be 10-15 digits long.');
                    isValid = false;
                }

                if (!isValid) {
                    e.preventDefault(); // Prevent form submission if validation fails
                }
            });
        });
    </script>
</body>
</html>
